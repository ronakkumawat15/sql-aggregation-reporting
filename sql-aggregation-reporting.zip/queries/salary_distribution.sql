SELECT FLOOR(s.salary/10000)*10000 AS Salary_Bucket,
COUNT(*) AS Employees
FROM salaries s
GROUP BY Salary_Bucket;
