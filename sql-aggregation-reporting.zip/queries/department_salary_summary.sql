SELECT d.dept_name,
COUNT(DISTINCT e.emp_no) AS Employees,
ROUND(AVG(s.salary),2) AS Avg_Salary
FROM departments d
JOIN dept_emp de ON d.dept_no = de.dept_no
JOIN employees e ON de.emp_no = e.emp_no
JOIN salaries s ON e.emp_no = s.emp_no
WHERE de.to_date > CURDATE()
AND s.to_date > CURDATE()
GROUP BY d.dept_name;
