SELECT YEAR(hire_date) AS Hire_Year,
COUNT(*) AS New_Hires
FROM employees
GROUP BY Hire_Year;
