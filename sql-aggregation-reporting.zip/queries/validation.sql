SELECT COUNT(DISTINCT emp_no)
FROM salaries
WHERE to_date > CURDATE();
