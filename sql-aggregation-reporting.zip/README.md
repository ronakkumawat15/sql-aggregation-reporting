# SQL Project: Data Aggregation & Reporting

## Description
This project demonstrates SQL aggregation and reporting techniques.

## Objective
To generate reports using GROUP BY, HAVING, and window functions.

## Tools Used
- MySQL

## Dataset
employees, salaries, departments, dept_emp

## Key Concepts
- GROUP BY
- HAVING
- JOIN
- Window Functions
