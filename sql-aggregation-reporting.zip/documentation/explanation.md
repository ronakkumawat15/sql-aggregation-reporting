# Explanation

Covers GROUP BY, HAVING, JOIN, and window functions.
